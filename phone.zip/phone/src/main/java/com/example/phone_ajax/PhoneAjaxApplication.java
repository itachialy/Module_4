package com.example.phone_ajax;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhoneAjaxApplication {

    public static void main(String[] args) {
        SpringApplication.run(PhoneAjaxApplication.class, args);
    }

}
