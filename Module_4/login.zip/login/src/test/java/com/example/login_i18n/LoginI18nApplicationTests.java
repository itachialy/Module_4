package com.example.login_i18n;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginI18nApplicationTests {

    @Test
    void contextLoads() {
    }

}
