package com.example.login_i18n;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginI18nApplication {

    public static void main(String[] args) {
        SpringApplication.run(LoginI18nApplication.class, args);
    }

}
